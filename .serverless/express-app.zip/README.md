# Make Parties :balloon:
by reikamoon :ribbon: <br/>
[Link to Heroku Deployment](https://make-parties-aa.herokuapp.com/)<br/>

## Made with... :computer:
node.js, sequelize, handlebars, express, moment.js, Postgres :elephant:

## How It Works :tada:
Allows users to create, edit, and delete events on the homepage.<br/>
Users can give events names, descriptions, as well as add an image! <br/>
Users can RSVP by leaving their name and email address, and can remove RSVP anytime.<br/>

## Tutorial :pencil:
[Tutorial Used](https://www.makeschool.com/academy/track/make-tweets)
